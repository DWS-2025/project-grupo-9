package com.gym_admin.controllers;

import com.gym_admin.models.Routine;
import com.gym_admin.services.RoutineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/routines")
public class RoutineController {

    private final RoutineService routineService;

    @Autowired
    public RoutineController(RoutineService routineService) {
        this.routineService = routineService;
    }

    // Método para mostrar la página con las rutinas
    @GetMapping
    public String showRoutinesPage() {
        return "routines";  // Spring buscará el archivo routines.html en el directorio templates/
    }

    // Método para obtener todas las rutinas en formato JSON
    @GetMapping("/api")
    @ResponseBody
    public List<Routine> getAllRoutines() {
        return routineService.getAllRoutines();  // Devuelve las rutinas en formato JSON
    }
}
