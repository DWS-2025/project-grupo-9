package com.example.gym_admin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GymAdminApplicationTests {

    @Test
    void contextLoads() {
    }

}
